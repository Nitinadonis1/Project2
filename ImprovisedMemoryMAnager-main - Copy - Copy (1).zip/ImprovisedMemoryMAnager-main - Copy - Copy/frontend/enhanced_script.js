// enhanced_script.js - Complete Frontend Logic with All Features
// Handles all UI interactions, API calls, and visualizations

// Configuration
const API_BASE_URL = 'http://localhost:5000/api';

// State Management
let currentMemoryState = null;
let currentProcesses = [];
let schedulingInfo = null;
let autoExecuteInterval = null;

// DOM Elements - Tabs
const tabs = document.querySelectorAll('.tab');
const tabContents = document.querySelectorAll('.tab-content');

// DOM Elements - Memory Tab
const allocateForm = document.getElementById('allocateForm');
const switchAllocatorBtn = document.getElementById('switchAllocatorBtn');
const compactBtn = document.getElementById('compactBtn');
const resetBtn = document.getElementById('resetBtn');
const memoryViz = document.getElementById('memoryViz');
const processTableBody = document.getElementById('processTableBody');

// DOM Elements - Scheduling Tab
const configScheduleBtn = document.getElementById('configScheduleBtn');
const executeStepBtn = document.getElementById('executeStepBtn');
const autoExecuteBtn = document.getElementById('autoExecuteBtn');
const stopAutoBtn = document.getElementById('stopAutoBtn');
const schedProcessTable = document.getElementById('schedProcessTable');
const currentProcessDiv = document.getElementById('currentProcess');
const readyQueueDiv = document.getElementById('readyQueue');
const ganttChartDiv = document.getElementById('ganttChart');

// DOM Elements - Diagnostics Tab
const refreshLogsBtn = document.getElementById('refreshLogsBtn');
const clearLogsBtn = document.getElementById('clearLogsBtn');
const memoryEventsDiv = document.getElementById('memoryEvents');
const allocationHistoryDiv = document.getElementById('allocationHistory');

// DOM Elements - Reports Tab
const exportCsvBtn = document.getElementById('exportCsvBtn');
const exportJsonBtn = document.getElementById('exportJsonBtn');
const viewStatsBtn = document.getElementById('viewStatsBtn');
const statsDisplay = document.getElementById('statsDisplay');
const statsContent = document.getElementById('statsContent');

// DOM Elements - Notification
const notification = document.getElementById('notification');
const notificationMessage = document.getElementById('notificationMessage');

// ==================== Event Listeners ====================
document.addEventListener('DOMContentLoaded', initializeApp);

// Tab Navigation
tabs.forEach(tab => {
    tab.addEventListener('click', () => {
        const tabName = tab.dataset.tab;
        switchTab(tabName);
    });
});

// Memory Tab Events
allocateForm.addEventListener('submit', handleAllocate);
switchAllocatorBtn.addEventListener('click', handleSwitchAllocator);
compactBtn.addEventListener('click', handleCompact);
resetBtn.addEventListener('click', handleReset);

// Scheduling Tab Events
configScheduleBtn.addEventListener('click', handleConfigureScheduling);
executeStepBtn.addEventListener('click', handleExecuteStep);
autoExecuteBtn.addEventListener('click', handleAutoExecute);
stopAutoBtn.addEventListener('click', handleStopAuto);

// Diagnostics Tab Events
refreshLogsBtn.addEventListener('click', handleRefreshLogs);
clearLogsBtn.addEventListener('click', handleClearLogs);

// Reports Tab Events
exportCsvBtn.addEventListener('click', handleExportCsv);
exportJsonBtn.addEventListener('click', handleExportJson);
viewStatsBtn.addEventListener('click', handleViewStats);

// Show/hide time quantum based on algorithm
document.getElementById('schedAlgorithm').addEventListener('change', (e) => {
    const quantumGroup = document.getElementById('quantumGroup');
    quantumGroup.style.display = e.target.value === 'round_robin' ? 'block' : 'none';
});

// ==================== Initialization ====================
async function initializeApp() {
    console.log('Enhanced Memory Manager initialized');
    await fetchMemoryState();
    await fetchSchedulingInfo();
}

function switchTab(tabName) {
    tabs.forEach(t => t.classList.remove('active'));
    tabContents.forEach(tc => tc.classList.remove('active'));
    
    const activeTab = document.querySelector(`[data-tab="${tabName}"]`);
    const activeContent = document.getElementById(tabName);
    
    if (activeTab && activeContent) {
        activeTab.classList.add('active');
        activeContent.classList.add('active');
        
        // Refresh data when switching to specific tabs
        if (tabName === 'diagnostics') {
            handleRefreshLogs();
        } else if (tabName === 'scheduling') {
            fetchSchedulingInfo();
        }
    }
}

// ==================== API Functions ====================
async function apiRequest(endpoint, method = 'GET', data = null) {
    try {
        const options = {
            method: method,
            headers: {
                'Content-Type': 'application/json',
            }
        };

        if (data) {
            options.body = JSON.stringify(data);
        }

        const response = await fetch(`${API_BASE_URL}${endpoint}`, options);
        const result = await response.json();
        
        return result;
    } catch (error) {
        console.error('API Error:', error);
        showNotification('Error connecting to server. Make sure backend is running.', 'error');
        return { success: false, message: 'Connection error' };
    }
}

async function fetchMemoryState() {
    const result = await apiRequest('/memory-state', 'GET');
    
    if (result.success) {
        currentMemoryState = result.memory_state;
        currentProcesses = result.processes;
        updateMemoryUI();
    }
}

async function fetchSchedulingInfo() {
    const result = await apiRequest('/scheduling/info', 'GET');
    
    if (result.success) {
        schedulingInfo = result.scheduling_info;
        updateSchedulingUI();
    }
}

// ==================== Memory Allocation Handlers ====================
async function handleAllocate(e) {
    e.preventDefault();
    
    const size = parseInt(document.getElementById('processSize').value);
    const algorithm = (document.getElementById('algorithm').value);
    const priority = parseInt(document.getElementById('priority').value);
    const burstTime = parseInt(document.getElementById('burstTime').value);
    
    if (size <= 0 || size > 1024) {
        showNotification('Invalid process size. Must be between 1 and 1024 KB', 'error');
        return;
    }
    
    const result = await apiRequest('/allocate', 'POST', {
        size: size,
        algorithm: algorithm,
        priority: priority,
        burst_time: burstTime
    });
    
    if (result.success) {
        showNotification(result.message, 'success');
        currentMemoryState = result.memory_state;
        currentProcesses = result.processes;
        updateMemoryUI();
        await fetchSchedulingInfo(); // Update scheduling info
    } else {
        showNotification(result.message, 'error');
    }
}

async function handleDeallocate(processId) {
    const result = await apiRequest('/deallocate', 'POST', {
        process_id: processId
    });
    
    if (result.success) {
        showNotification(result.message, 'success');
        currentMemoryState = result.memory_state;
        currentProcesses = result.processes;
        updateMemoryUI();
        await fetchSchedulingInfo();
    } else {
        showNotification(result.message, 'error');
    }
}

async function handleCompact() {
    const result = await apiRequest('/compact', 'POST');
    
    if (result.success) {
        showNotification(result.message, 'success');
        currentMemoryState = result.memory_state;
        currentProcesses = result.processes;
        updateMemoryUI();
    } else {
        showNotification(result.message, 'error');
    }
}

async function handleReset() {
    if (!confirm('Are you sure you want to reset all memory? This will remove all processes.')) {
        return;
    }
    
    const result = await apiRequest('/reset', 'POST');
    
    if (result.success) {
        showNotification(result.message, 'success');
        currentMemoryState = result.memory_state;
        currentProcesses = result.processes;
        updateMemoryUI();
        await fetchSchedulingInfo();
    } else {
        showNotification(result.message, 'error');
    }
}

async function handleSwitchAllocator() {
    const allocatorType = document.getElementById('allocatorType').value;
    
    if (!confirm(`Switch to ${allocatorType} allocator? This will reset all memory.`)) {
        return;
    }
    
    const result = await apiRequest('/switch-allocator', 'POST', {
        type: allocatorType
    });
    
    if (result.success) {
        showNotification(result.message, 'success');
        currentMemoryState = result.memory_state;
        currentProcesses = [];
        updateMemoryUI();
    } else {
        showNotification(result.message, 'error');
    }
}

// ==================== Scheduling Handlers ====================
async function handleConfigureScheduling() {
    const algorithm = document.getElementById('schedAlgorithm').value;
    const timeQuantum = parseInt(document.getElementById('timeQuantum').value);
    
    const result = await apiRequest('/scheduling/configure', 'POST', {
        algorithm: algorithm,
        time_quantum: timeQuantum
    });
    
    if (result.success) {
        showNotification(result.message, 'success');
        schedulingInfo = result.scheduling_info;
        updateSchedulingUI();
    } else {
        showNotification(result.message, 'error');
    }
}

async function handleExecuteStep() {
    const result = await apiRequest('/scheduling/execute', 'POST');
    
    if (result.success) {
        await fetchSchedulingInfo();
        await fetchMemoryState();
    } else {
        showNotification(result.message || 'Execution failed', 'error');
    }
}

function handleAutoExecute() {
    autoExecuteBtn.style.display = 'none';
    stopAutoBtn.style.display = 'block';
    
    autoExecuteInterval = setInterval(async () => {
        await handleExecuteStep();
    }, 2000);
    
    showNotification('Auto-execution started', 'info');
}

function handleStopAuto() {
    if (autoExecuteInterval) {
        clearInterval(autoExecuteInterval);
        autoExecuteInterval = null;
    }
    
    autoExecuteBtn.style.display = 'block';
    stopAutoBtn.style.display = 'none';
    
    showNotification('Auto-execution stopped', 'info');
}

// ==================== Diagnostics Handlers ====================
async function handleRefreshLogs() {
    // Fetch memory events
    const eventsResult = await apiRequest('/memory-events', 'GET');
    if (eventsResult.success) {
        displayMemoryEvents(eventsResult.events);
    }
    
    // Fetch allocation history
    const historyResult = await apiRequest('/allocation-history', 'GET');
    if (historyResult.success) {
        displayAllocationHistory(historyResult.history);
    }
    
    showNotification('Logs refreshed', 'success');
}

function handleClearLogs() {
    memoryEventsDiv.innerHTML = '<p style="color: #94a3b8;">Logs cleared</p>';
    allocationHistoryDiv.innerHTML = '<p style="color: #94a3b8;">History cleared</p>';
    showNotification('Logs cleared', 'info');
}

// ==================== Report Handlers ====================
async function handleExportCsv() {
    try {
        const response = await fetch(`${API_BASE_URL}/export/csv`);
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `memory_report_${Date.now()}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        showNotification('CSV report downloaded', 'success');
    } catch (error) {
        showNotification('Export failed', 'error');
    }
}

async function handleExportJson() {
    try {
        const response = await fetch(`${API_BASE_URL}/export/json`);
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `system_state_${Date.now()}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        showNotification('JSON export downloaded', 'success');
    } catch (error) {
        showNotification('Export failed', 'error');
    }
}

async function handleViewStats() {
    const result = await apiRequest('/statistics', 'GET');
    
    if (result.success) {
        const stats = result.statistics;
        let html = '<div class="stat-list">';
        
        for (const [key, value] of Object.entries(stats)) {
            html += `<div class="stat-row">
                <span class="stat-key">${formatKey(key)}:</span>
                <span class="stat-val">${value}</span>
            </div>`;
        }
        
        html += '</div>';
        statsContent.innerHTML = html;
        statsDisplay.style.display = 'block';
    } else {
        showNotification('Failed to fetch statistics', 'error');
    }
}

function formatKey(key) {
    return key.split('_').map(word => 
        word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
}

// ==================== UI Update Functions ====================
function updateMemoryUI() {
    if (!currentMemoryState) return;
    
    updateMemoryVisualization();
    updateProcessTable();
    updateStatistics();
}

function updateMemoryVisualization() {
    memoryViz.innerHTML = '';
    
    if (!currentMemoryState || !currentMemoryState.blocks) return;
    
    const totalMemory = currentMemoryState.total_memory;
    
    currentMemoryState.blocks.forEach(block => {
        const blockEl = document.createElement('div');
        blockEl.className = `memory-block ${block.is_free ? 'free' : 'allocated'}`;
        
        const leftPercent = (block.start / totalMemory) * 100;
        const widthPercent = (block.size / totalMemory) * 100;
        
        blockEl.style.left = `${leftPercent}%`;
        blockEl.style.width = `${widthPercent}%`;
        
        const label = document.createElement('div');
        label.className = 'block-label';
        label.textContent = block.is_free ? 'FREE' : block.process_id;
        
        const size = document.createElement('div');
        size.className = 'block-size';
        size.textContent = `${block.size} KB`;
        
        blockEl.appendChild(label);
        blockEl.appendChild(size);
        
        blockEl.title = `${block.is_free ? 'Free Block' : 'Process ' + block.process_id}\nStart: ${block.start} KB\nSize: ${block.size} KB\nEnd: ${block.end} KB${block.internal_fragmentation ? '\nInternal Frag: ' + block.internal_fragmentation + ' KB' : ''}`;
        
        memoryViz.appendChild(blockEl);
    });
}

function updateProcessTable() {
    processTableBody.innerHTML = '';
    
    if (!currentProcesses || currentProcesses.length === 0) {
        processTableBody.innerHTML = '<tr><td colspan="9" style="text-align: center; color: #94a3b8;">No active processes</td></tr>';
        return;
    }
    
    currentProcesses.forEach(process => {
        const row = document.createElement('tr');
        
        row.innerHTML = `
            <td><strong>${process.process_id}</strong></td>
            <td>${process.size} KB</td>
            <td><span class="badge badge-${process.state.toLowerCase()}">${process.state}</span></td>
            <td>${process.priority}</td>
            <td>${process.start_address} KB</td>
            <td>${process.end_address} KB</td>
            <td>${process.burst_time}</td>
            <td>${process.remaining_time}</td>
            <td>
                <button class="btn btn-danger" style="width: auto; padding: 6px 12px; font-size: 0.85rem;" onclick="handleDeallocate('${process.process_id}')">
                    Deallocate
                </button>
            </td>
        `;
        
        processTableBody.appendChild(row);
    });
}

function updateStatistics() {
    if (!currentMemoryState) return;
    
    document.getElementById('totalMemory').textContent = `${currentMemoryState.total_memory} KB`;
    document.getElementById('allocatedMemory').textContent = `${currentMemoryState.allocated} KB`;
    document.getElementById('freeMemory').textContent = `${currentMemoryState.free} KB`;
    document.getElementById('processCount').textContent = currentProcesses.length;
    document.getElementById('freeBlocks').textContent = currentMemoryState.num_free_blocks;
    document.getElementById('allocatedBlocks').textContent = currentMemoryState.num_allocated_blocks;
    
    const utilization = ((currentMemoryState.allocated / currentMemoryState.total_memory) * 100).toFixed(2);
    document.getElementById('utilization').textContent = `${utilization}%`;
    
    const externalFrag = currentMemoryState.external_fragmentation.toFixed(2);
    document.getElementById('externalFrag').textContent = `${externalFrag}%`;
    
    const internalFrag = currentMemoryState.internal_fragmentation || 0;
    document.getElementById('internalFrag').textContent = `${internalFrag} KB`;
    
    updateStatColors(utilization, externalFrag);
}

function updateStatColors(utilization, fragmentation) {
    const utilizationEl = document.getElementById('utilization');
    const fragmentationEl = document.getElementById('externalFrag');
    
    if (utilization < 50) {
        utilizationEl.style.color = '#10b981';
    } else if (utilization < 80) {
        utilizationEl.style.color = '#f59e0b';
    } else {
        utilizationEl.style.color = '#ef4444';
    }
    
    if (fragmentation < 10) {
        fragmentationEl.style.color = '#10b981';
    } else if (fragmentation < 25) {
        fragmentationEl.style.color = '#f59e0b';
    } else {
        fragmentationEl.style.color = '#ef4444';
    }
}

// ==================== Scheduling UI Updates ====================
function updateSchedulingUI() {
    if (!schedulingInfo) return;
    
    updateCurrentProcess();
    updateReadyQueue();
    updateGanttChart();
    updateSchedulingMetrics();
    updateSchedulingTable();
}

function updateCurrentProcess() {
    if (schedulingInfo.current_process) {
        const process = schedulingInfo.current_process;
        currentProcessDiv.innerHTML = `
            <h4 style="color: var(--primary); margin-bottom: 10px;">${process.process_id}</h4>
            <div class="process-info">
                <div class="process-info-item">
                    <span>Size:</span>
                    <strong>${process.size} KB</strong>
                </div>
                <div class="process-info-item">
                    <span>Priority:</span>
                    <strong>${process.priority}</strong>
                </div>
                <div class="process-info-item">
                    <span>Burst Time:</span>
                    <strong>${process.burst_time}</strong>
                </div>
                <div class="process-info-item">
                    <span>Remaining:</span>
                    <strong>${process.remaining_time}</strong>
                </div>
            </div>
        `;
    } else {
        currentProcessDiv.innerHTML = '<p style="color: #94a3b8;">No process running</p>';
    }
}

function updateReadyQueue() {
    if (schedulingInfo.ready_queue && schedulingInfo.ready_queue.length > 0) {
        readyQueueDiv.innerHTML = schedulingInfo.ready_queue.map(proc => 
            `<div class="queue-item">${typeof proc === 'string' ? proc : proc.process_id}</div>`
        ).join('');
    } else {
        readyQueueDiv.innerHTML = '<p style="color: #94a3b8;">Queue is empty</p>';
    }
}

function updateGanttChart() {
    if (schedulingInfo.gantt_chart && schedulingInfo.gantt_chart.length > 0) {
        const last10 = schedulingInfo.gantt_chart.slice(-10);
        ganttChartDiv.innerHTML = last10.map(entry => 
            `<div class="gantt-block">
                <div>${entry.process_id}</div>
                <div style="font-size: 0.75rem; opacity: 0.8;">${entry.start_time}-${entry.end_time}</div>
            </div>`
        ).join('');
    } else {
        ganttChartDiv.innerHTML = '<p style="color: #94a3b8; padding: 20px;">No execution history</p>';
    }
}

function updateSchedulingMetrics() {
    if (schedulingInfo.metrics) {
        const metrics = schedulingInfo.metrics;
        document.getElementById('avgWaiting').textContent = `${metrics.avg_waiting_time.toFixed(2)}s`;
        document.getElementById('avgTurnaround').textContent = `${metrics.avg_turnaround_time.toFixed(2)}s`;
        document.getElementById('avgResponse').textContent = `${metrics.avg_response_time.toFixed(2)}s`;
    }
}

function updateSchedulingTable() {
    if (!currentProcesses || currentProcesses.length === 0) {
        schedProcessTable.innerHTML = '<tr><td colspan="7" style="text-align: center; color: #94a3b8;">No processes</td></tr>';
        return;
    }
    
    schedProcessTable.innerHTML = currentProcesses.map(process => `
        <tr>
            <td><strong>${process.process_id}</strong></td>
            <td><span class="badge badge-${process.state.toLowerCase()}">${process.state}</span></td>
            <td>${process.priority}</td>
            <td>${process.burst_time}</td>
            <td>${process.remaining_time}</td>
            <td>${process.waiting_time ? process.waiting_time.toFixed(2) : '0.00'}s</td>
            <td>${process.turnaround_time ? process.turnaround_time.toFixed(2) : '0.00'}s</td>
        </tr>
    `).join('');
}

// ==================== Diagnostics UI Updates ====================
function displayMemoryEvents(events) {
    if (!events || events.length === 0) {
        memoryEventsDiv.innerHTML = '<p style="color: #94a3b8;">No events logged</p>';
        return;
    }
    
    memoryEventsDiv.innerHTML = events.reverse().map(event => {
        const time = new Date(event.timestamp).toLocaleString();
        const cls = event.success ? 'success' : 'error';
        return `
            <div class="log-entry ${cls}">
                <div class="log-time">${time}</div>
                <div><strong>${event.event_type.toUpperCase()}</strong> - ${event.process_id || 'System'} - ${event.size} KB - ${event.success ? 'Success' : 'Failed'}</div>
            </div>
        `;
    }).join('');
}

function displayAllocationHistory(history) {
    if (!history || history.length === 0) {
        allocationHistoryDiv.innerHTML = '<p style="color: #94a3b8;">No allocation history</p>';
        return;
    }
    
    allocationHistoryDiv.innerHTML = history.reverse().map(entry => {
        const time = new Date(entry.timestamp).toLocaleString();
        const cls = entry.success ? 'success' : 'error';
        return `
            <div class="log-entry ${cls}">
                <div class="log-time">${time}</div>
                <div>${entry.process_id} - ${entry.size} KB - Algorithm: ${entry.algorithm} - ${entry.success ? 'Success' : 'Failed'}</div>
            </div>
        `;
    }).join('');
}

// ==================== Notification System ====================
function showNotification(message, type = 'success') {
    notificationMessage.textContent = message;
    notification.className = `notification ${type}`;
    
    setTimeout(() => {
        notification.classList.add('hidden');
    }, 3000);
}

// ==================== Auto Refresh ====================
setInterval(() => {
    fetchMemoryState();
    if (document.querySelector('[data-tab="scheduling"]').classList.contains('active')) {
        fetchSchedulingInfo();
    }
}, 5000);

// Make handleDeallocate available globally
window.handleDeallocate = handleDeallocate;