

from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from enhanced_memory_allocator import MemoryAllocator
from enhanced_process_manager import ProcessManager
import json
from datetime import datetime
import io
import csv

app = Flask(__name__)
CORS(app)


standard_allocator = MemoryAllocator(total_memory=1024, enable_buddy=False)
buddy_allocator = MemoryAllocator(total_memory=1024, enable_buddy=True)

# Use standard allocator by default
current_allocator = standard_allocator
process_manager = ProcessManager(current_allocator)


@app.route('/api/allocate', methods=['POST'])
def allocate_memory():
    """Allocate memory for a new process with enhanced options"""
    try:
        data = request.get_json()
        size = int(data.get('size', 0))
        algorithm = data.get('algorithm', 'first_fit')
        priority = int(data.get('priority', 0))
        burst_time = int(data.get('burst_time', 10))
        
        result = process_manager.allocate_process(size, algorithm, priority, burst_time)
        memory_state = current_allocator.get_memory_state()
        processes = process_manager.get_all_processes()
        
        return jsonify({
            **result,
            'memory_state': memory_state,
            'processes': processes
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400


@app.route('/api/deallocate', methods=['POST'])
def deallocate_memory():
    """Deallocate memory for a process"""
    try:
        data = request.get_json()
        process_id = data.get('process_id')
        
        result = process_manager.deallocate_process(process_id)
        memory_state = current_allocator.get_memory_state()
        processes = process_manager.get_all_processes()
        
        return jsonify({
            **result,
            'memory_state': memory_state,
            'processes': processes
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400


@app.route('/api/compact', methods=['POST'])
def compact_memory():
    """Compact memory"""
    try:
        result = process_manager.compact_memory()
        memory_state = current_allocator.get_memory_state()
        processes = process_manager.get_all_processes()
        
        return jsonify({
            **result,
            'memory_state': memory_state,
            'processes': processes
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400


@app.route('/api/reset', methods=['POST'])
def reset_memory():
    """Reset memory"""
    try:
        result = process_manager.reset_memory()
        memory_state = current_allocator.get_memory_state()
        
        return jsonify({
            **result,
            'memory_state': memory_state,
            'processes': []
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400


@app.route('/api/memory-state', methods=['GET'])
def get_memory_state():
    """Get current memory state with enhanced metrics"""
    try:
        memory_state = current_allocator.get_memory_state()
        processes = process_manager.get_all_processes()
        
        return jsonify({
            'success': True,
            'memory_state': memory_state,
            'processes': processes
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400


@app.route('/api/statistics', methods=['GET'])
def get_statistics():
    """Get comprehensive memory statistics"""
    try:
        memory_state = current_allocator.get_memory_state()
        processes = process_manager.get_all_processes()
        
        stats = {
            'total_memory': memory_state['total_memory'],
            'allocated_memory': memory_state['allocated'],
            'free_memory': memory_state['free'],
            'external_fragmentation': round(memory_state['external_fragmentation'], 2),
            'internal_fragmentation': round(memory_state['internal_fragmentation'], 2),
            'internal_fragmentation_percent': round(memory_state['internal_fragmentation_percent'], 2),
            'total_fragmentation': round(memory_state['total_fragmentation'], 2),
            'total_processes': len(processes),
            'num_allocated_blocks': memory_state['num_allocated_blocks'],
            'num_free_blocks': memory_state['num_free_blocks'],
            'largest_free_block': memory_state['largest_free_block'],
            'utilization': round((memory_state['allocated'] / memory_state['total_memory']) * 100, 2),
            'allocation_count': memory_state['allocation_count'],
            'buddy_system_enabled': memory_state['buddy_system_enabled']
        }
        
        return jsonify({'success': True, 'statistics': stats})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400


@app.route('/api/scheduling/configure', methods=['POST'])
def configure_scheduling():
    """Configure scheduling algorithm"""
    try:
        data = request.get_json()
        algorithm = data.get('algorithm', 'fcfs')
        time_quantum = int(data.get('time_quantum', 4))
        
        process_manager.set_scheduling_algorithm(algorithm, time_quantum)
        
        return jsonify({
            'success': True,
            'message': f'Scheduling algorithm set to {algorithm}',
            'scheduling_info': process_manager.get_scheduling_info()
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400


@app.route('/api/scheduling/execute', methods=['POST'])
def execute_scheduling():
    """Execute one scheduling cycle"""
    try:
        result = process_manager.execute_scheduling_cycle()
        
        return jsonify({
            'success': True,
            **result
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400


@app.route('/api/scheduling/info', methods=['GET'])
def get_scheduling_info():
    """Get scheduling information"""
    try:
        info = process_manager.get_scheduling_info()
        
        return jsonify({
            'success': True,
            'scheduling_info': info
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400


@app.route('/api/memory-events', methods=['GET'])
def get_memory_events():
    """Get memory event log"""
    try:
        events = process_manager.get_memory_events()
        
        return jsonify({
            'success': True,
            'events': events
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400


@app.route('/api/allocation-history', methods=['GET'])
def get_allocation_history():
    """Get allocation history"""
    try:
        history = current_allocator.get_allocation_history()
        
        return jsonify({
            'success': True,
            'history': history
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400


@app.route('/api/switch-allocator', methods=['POST'])
def switch_allocator():
    """Switch between standard and buddy allocator"""
    global current_allocator, process_manager
    
    try:
        data = request.get_json()
        allocator_type = data.get('type', 'standard')
        
        # Save current state
        if allocator_type == 'buddy':
            current_allocator = buddy_allocator
        else:
            current_allocator = standard_allocator
        
        # Create new process manager with selected allocator
        process_manager = ProcessManager(current_allocator)
        
        return jsonify({
            'success': True,
            'message': f'Switched to {allocator_type} allocator',
            'memory_state': current_allocator.get_memory_state()
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400


@app.route('/api/export/csv', methods=['GET'])
def export_csv():
    """Export memory state to CSV"""
    try:
        memory_state = current_allocator.get_memory_state()
        processes = process_manager.get_all_processes()
        
        # Create CSV in memory
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Write header
        writer.writerow(['Timestamp', datetime.now().isoformat()])
        writer.writerow([])
        
        # Write memory blocks
        writer.writerow(['Memory Blocks'])
        writer.writerow(['Start', 'Size', 'End', 'Type', 'Process ID', 'Internal Fragmentation'])
        for block in memory_state['blocks']:
            writer.writerow([
                block['start'],
                block['size'],
                block['end'],
                'Free' if block['is_free'] else 'Allocated',
                block['process_id'] if block['process_id'] else 'N/A',
                block.get('internal_fragmentation', 0)
            ])
        
        writer.writerow([])
        
        # Write processes
        writer.writerow(['Active Processes'])
        writer.writerow(['Process ID', 'Size', 'Priority', 'State', 'Start Address', 'End Address', 'Burst Time', 'Remaining Time'])
        for process in processes:
            writer.writerow([
                process['process_id'],
                process['size'],
                process['priority'],
                process['state'],
                process['start_address'],
                process['end_address'],
                process['burst_time'],
                process['remaining_time']
            ])
        
        writer.writerow([])
        
        # Write statistics
        writer.writerow(['Statistics'])
        stats = memory_state
        writer.writerow(['Total Memory', stats['total_memory']])
        writer.writerow(['Allocated', stats['allocated']])
        writer.writerow(['Free', stats['free']])
        writer.writerow(['External Fragmentation', f"{stats['external_fragmentation']:.2f}%"])
        writer.writerow(['Internal Fragmentation', f"{stats['internal_fragmentation']} KB"])
        writer.writerow(['Internal Fragmentation %', f"{stats['internal_fragmentation_percent']:.2f}%"])
        
        output.seek(0)
        
        return send_file(
            io.BytesIO(output.getvalue().encode()),
            mimetype='text/csv',
            as_attachment=True,
            download_name=f'memory_report_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
        )
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400


@app.route('/api/export/json', methods=['GET'])
def export_json():
    """Export complete system state to JSON"""
    try:
        data = {
            'timestamp': datetime.now().isoformat(),
            'memory_state': current_allocator.get_memory_state(),
            'processes': process_manager.get_all_processes(),
            'scheduling_info': process_manager.get_scheduling_info(),
            'memory_events': process_manager.get_memory_events(),
            'allocation_history': current_allocator.get_allocation_history()
        }
        
        return send_file(
            io.BytesIO(json.dumps(data, indent=2).encode()),
            mimetype='application/json',
            as_attachment=True,
            download_name=f'system_state_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json'
        )
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400


if __name__ == '__main__':
    print("=" * 60)
    print("Enhanced Memory Manager Backend Server")
    print("=" * 60)
    print("\nFeatures:")
    print("✓ Memory Allocation: First-Fit, Best-Fit, Worst-Fit, Next-Fit")
    print("✓ Buddy System Allocation")
    print("✓ Process Scheduling: FCFS, Round Robin, Priority, SJF")
    print("✓ Process States: New, Ready, Running, Waiting, Terminated")
    print("✓ Fragmentation Analysis: Internal & External")
    print("✓ Memory Event Logging")
    print("✓ Export Reports: CSV & JSON")
    print("\nServer starting on http://localhost:5000")
    print("=" * 60)
    app.run(debug=True, port=5000)