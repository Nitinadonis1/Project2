# enhanced_process_manager.py - Process Management with Scheduling Algorithms
# Enhanced with FCFS, Round Robin, Priority Scheduling, and Process States

import time
from datetime import datetime
from enum import Enum
from collections import deque

class ProcessState(Enum):
    """Process states"""
    NEW = "New"
    READY = "Ready"
    RUNNING = "Running"
    WAITING = "Waiting"
    TERMINATED = "Terminated"

class Process:
    """Enhanced process with state management"""
    def __init__(self, process_id, size, priority=0, burst_time=10):
        self.process_id = process_id
        self.size = size
        self.priority = priority
        self.burst_time = burst_time  # CPU burst time
        self.remaining_time = burst_time
        self.state = ProcessState.NEW
        self.created_at = datetime.now()
        self.start_address = None
        self.end_address = None
        self.start_time = None
        self.completion_time = None
        self.waiting_time = 0
        self.turnaround_time = 0
        self.response_time = None
    
    def to_dict(self):
        """Convert process to dictionary"""
        return {
            'process_id': self.process_id,
            'size': self.size,
            'priority': self.priority,
            'state': self.state.value,
            'start_address': self.start_address,
            'end_address': self.end_address,
            'burst_time': self.burst_time,
            'remaining_time': self.remaining_time,
            'waiting_time': self.waiting_time,
            'turnaround_time': self.turnaround_time,
            'created_at': self.created_at.isoformat(),
            'start_time': self.start_time.isoformat() if self.start_time else None,
            'completion_time': self.completion_time.isoformat() if self.completion_time else None
        }


class ProcessScheduler:
    """Process scheduler with multiple algorithms"""
    
    def __init__(self, algorithm='fcfs', time_quantum=4):
        self.algorithm = algorithm
        self.time_quantum = time_quantum
        self.ready_queue = deque()
        self.running_process = None
        self.current_time = 0
        self.gantt_chart = []
    
    def add_to_ready_queue(self, process):
        """Add process to ready queue"""
        process.state = ProcessState.READY
        
        if self.algorithm == 'priority':
            # Priority queue - higher priority first (lower number = higher priority)
            inserted = False
            for i, p in enumerate(self.ready_queue):
                if process.priority < p.priority:
                    self.ready_queue.insert(i, process)
                    inserted = True
                    break
            if not inserted:
                self.ready_queue.append(process)
        else:
            self.ready_queue.append(process)
    
    def schedule_next(self):
        """Schedule next process based on algorithm"""
        if self.running_process:
            return self.running_process
        
        if not self.ready_queue:
            return None
        
        if self.algorithm in ['fcfs', 'round_robin']:
            next_process = self.ready_queue.popleft()
        elif self.algorithm == 'priority':
            next_process = self.ready_queue.popleft()
        elif self.algorithm == 'sjf':  # Shortest Job First
            next_process = min(self.ready_queue, key=lambda p: p.remaining_time)
            self.ready_queue.remove(next_process)
        else:
            next_process = self.ready_queue.popleft()
        
        next_process.state = ProcessState.RUNNING
        if next_process.start_time is None:
            next_process.start_time = datetime.now()
            next_process.response_time = (next_process.start_time - next_process.created_at).total_seconds()
        
        self.running_process = next_process
        return next_process
    
    def execute_time_slice(self):
        """Execute one time slice"""
        if not self.running_process:
            self.running_process = self.schedule_next()
        
        if not self.running_process:
            return None
        
        process = self.running_process
        
        # Execute for time quantum or remaining time
        exec_time = min(self.time_quantum, process.remaining_time)
        process.remaining_time -= exec_time
        self.current_time += exec_time
        
        # Record in Gantt chart
        self.gantt_chart.append({
            'process_id': process.process_id,
            'start_time': self.current_time - exec_time,
            'end_time': self.current_time
        })
        
        # Check if process completed
        if process.remaining_time <= 0:
            process.state = ProcessState.TERMINATED
            process.completion_time = datetime.now()
            process.turnaround_time = (process.completion_time - process.created_at).total_seconds()
            process.waiting_time = process.turnaround_time - process.burst_time
            self.running_process = None
            return process
        
        # For round robin, move to back of queue
        if self.algorithm == 'round_robin':
            process.state = ProcessState.READY
            self.ready_queue.append(process)
            self.running_process = None
        
        return process
    
    def get_average_metrics(self, completed_processes):
        """Calculate average scheduling metrics"""
        if not completed_processes:
            return {
                'avg_waiting_time': 0,
                'avg_turnaround_time': 0,
                'avg_response_time': 0
            }
        
        return {
            'avg_waiting_time': sum(p.waiting_time for p in completed_processes) / len(completed_processes),
            'avg_turnaround_time': sum(p.turnaround_time for p in completed_processes) / len(completed_processes),
            'avg_response_time': sum(p.response_time for p in completed_processes if p.response_time) / len(completed_processes)
        }


class ProcessManager:
    """Enhanced process manager with scheduling"""
    
    def __init__(self, allocator):
        self.allocator = allocator
        self.processes = {}
        self.completed_processes = []
        self.next_process_id = 1
        self.scheduler = ProcessScheduler(algorithm='fcfs')
        self.memory_events = []
    
    def set_scheduling_algorithm(self, algorithm, time_quantum=4):
        """Change scheduling algorithm"""
        self.scheduler = ProcessScheduler(algorithm=algorithm, time_quantum=time_quantum)
        
        # Re-add all ready processes to new scheduler
        for process in self.processes.values():
            if process.state == ProcessState.READY:
                self.scheduler.add_to_ready_queue(process)
    
    def allocate_process(self, size, algorithm='first_fit', priority=0, burst_time=10):
        """Allocate memory for a new process"""
        if size <= 0 or size > self.allocator.total_memory:
            return {'success': False, 'message': 'Invalid process size'}
        
        process_id = f"P{self.next_process_id}"
        self.next_process_id += 1
        
        # Allocate memory
        block = self.allocator.allocate(size, process_id, algorithm)
        
        if block:
            process = Process(process_id, size, priority, burst_time)
            process.start_address = block.start
            process.end_address = block.end
            process.state = ProcessState.READY
            
            self.processes[process_id] = process
            self.scheduler.add_to_ready_queue(process)
            
            self._log_memory_event('allocation', process_id, size, True)
            
            return {
                'success': True,
                'message': f'Process {process_id} allocated and added to ready queue',
                'process': process.to_dict()
            }
        else:
            self._log_memory_event('allocation', process_id, size, False)
            return {
                'success': False,
                'message': 'Insufficient memory or fragmentation'
            }
    
    def deallocate_process(self, process_id):
        """Deallocate memory for a process"""
        if process_id not in self.processes:
            return {'success': False, 'message': 'Process not found'}
        
        process = self.processes[process_id]
        process.state = ProcessState.TERMINATED
        
        # Remove from scheduler if present
        if process in self.scheduler.ready_queue:
            self.scheduler.ready_queue.remove(process)
        
        # Deallocate memory
        self.allocator.deallocate(process_id)
        
        # Merge adjacent free blocks
        self._merge_free_blocks()
        
        # Move to completed processes
        self.completed_processes.append(process)
        del self.processes[process_id]
        
        self._log_memory_event('deallocation', process_id, process.size, True)
        
        return {
            'success': True,
            'message': f'Process {process_id} deallocated successfully'
        }
    
    def _merge_free_blocks(self):
        """Merge adjacent free blocks to reduce fragmentation"""
        i = 0
        while i < len(self.allocator.blocks) - 1:
            current = self.allocator.blocks[i]
            next_block = self.allocator.blocks[i + 1]
            
            if current.is_free and next_block.is_free:
                current.size += next_block.size
                current.end = current.start + current.size - 1
                self.allocator.blocks.pop(i + 1)
            else:
                i += 1
    
    def compact_memory(self):
        """Compact memory by moving all processes to beginning"""
        allocated_blocks = [b for b in self.allocator.blocks if not b.is_free]
        
        if not allocated_blocks:
            return {'success': True, 'message': 'No processes to compact'}
        
        # Create new compacted blocks
        new_blocks = []
        current_start = 0
        
        for block in allocated_blocks:
            from enhanced_memory_allocator import MemoryBlock
            new_block = MemoryBlock(current_start, block.size, False, block.process_id)
            new_block.internal_fragmentation = block.internal_fragmentation
            new_blocks.append(new_block)
            
            # Update process addresses
            if block.process_id in self.processes:
                self.processes[block.process_id].start_address = current_start
                self.processes[block.process_id].end_address = current_start + block.size - 1
            
            current_start += block.size
        
        # Add remaining free space as one block
        remaining_size = self.allocator.total_memory - current_start
        if remaining_size > 0:
            from enhanced_memory_allocator import MemoryBlock
            new_blocks.append(MemoryBlock(current_start, remaining_size, True))
        
        self.allocator.blocks = new_blocks
        self._log_memory_event('compaction', None, 0, True)
        
        return {
            'success': True,
            'message': f'Memory compacted successfully. Freed {len(new_blocks)} blocks'
        }
    
    def execute_scheduling_cycle(self):
        """Execute one scheduling cycle"""
        result = self.scheduler.execute_time_slice()
        
        if result and result.state == ProcessState.TERMINATED:
            self.deallocate_process(result.process_id)
        
        return {
            'current_process': self.scheduler.running_process.to_dict() if self.scheduler.running_process else None,
            'ready_queue': [p.process_id for p in self.scheduler.ready_queue],
            'gantt_chart': self.scheduler.gantt_chart[-10:]  # Last 10 entries
        }
    
    def _log_memory_event(self, event_type, process_id, size, success):
        """Log memory management events"""
        self.memory_events.append({
            'timestamp': datetime.now().isoformat(),
            'event_type': event_type,
            'process_id': process_id,
            'size': size,
            'success': success
        })
        
        # Keep only last 100 events
        if len(self.memory_events) > 100:
            self.memory_events.pop(0)
    
    def get_all_processes(self):
        """Get all active processes"""
        return [p.to_dict() for p in self.processes.values()]
    
    def get_scheduling_info(self):
        """Get scheduling information"""
        return {
            'algorithm': self.scheduler.algorithm,
            'time_quantum': self.scheduler.time_quantum,
            'current_process': self.scheduler.running_process.to_dict() if self.scheduler.running_process else None,
            'ready_queue': [p.to_dict() for p in self.scheduler.ready_queue],
            'gantt_chart': self.scheduler.gantt_chart,
            'metrics': self.scheduler.get_average_metrics(self.completed_processes)
        }
    
    def get_memory_events(self):
        """Get memory event log"""
        return self.memory_events
    
    def reset_memory(self):
        """Reset entire memory system"""
        self.allocator.reset()
        self.processes.clear()
        self.completed_processes.clear()
        self.memory_events.clear()
        self.next_process_id = 1
        self.scheduler = ProcessScheduler(algorithm='fcfs')
        
        return {'success': True, 'message': 'Memory and processes reset successfully'}