# enhanced_memory_allocator.py - Advanced Memory Allocation with Buddy System
# Enhanced with Best-Fit, Worst-Fit, Buddy Allocation, and Internal Fragmentation tracking

import math
from datetime import datetime

class MemoryBlock:
    """Represents a block of memory with enhanced tracking"""
    def __init__(self, start, size, is_free=True, process_id=None, block_type='standard'):
        self.start = start
        self.size = size
        self.is_free = is_free
        self.process_id = process_id
        self.end = start + size - 1
        self.block_type = block_type  # 'standard' or 'buddy'
        self.buddy_order = None  # For buddy system
        self.internal_fragmentation = 0
        self.allocated_at = None

    def to_dict(self):
        """Convert block to dictionary for JSON serialization"""
        return {
            'start': self.start,
            'size': self.size,
            'end': self.end,
            'is_free': self.is_free,
            'process_id': self.process_id,
            'block_type': self.block_type,
            'buddy_order': self.buddy_order,
            'internal_fragmentation': self.internal_fragmentation,
            'allocated_at': self.allocated_at
        }


class MemoryAllocator:
    """Enhanced memory allocator with multiple algorithms"""
    
    def __init__(self, total_memory=1024, enable_buddy=False):
        self.total_memory = total_memory
        self.enable_buddy = enable_buddy
        self.allocation_count = 0
        self.allocation_history = []
        
        if enable_buddy:
            self._init_buddy_system()
        else:
            self.blocks = [MemoryBlock(0, total_memory, True)]
    
    def _init_buddy_system(self):
        """Initialize buddy system memory structure"""
        # Ensure total memory is power of 2
        if not self._is_power_of_2(self.total_memory):
            self.total_memory = 2 ** math.ceil(math.log2(self.total_memory))
        
        max_order = int(math.log2(self.total_memory))
        self.blocks = [MemoryBlock(0, self.total_memory, True, block_type='buddy')]
        self.blocks[0].buddy_order = max_order
    
    def _is_power_of_2(self, n):
        """Check if number is power of 2"""
        return n > 0 and (n & (n - 1)) == 0
    
    def allocate(self, process_size, process_id, algorithm='first_fit'):
        """Main allocation method routing to specific algorithm"""
        if self.enable_buddy and algorithm == 'buddy':
            return self.buddy_allocate(process_size, process_id)
        
        algorithms = {
            'first_fit': self.first_fit,
            'best_fit': self.best_fit,
            'worst_fit': self.worst_fit,
            'next_fit': self.next_fit
        }
        
        if algorithm not in algorithms:
            return None
        
        result = algorithms[algorithm](process_size, process_id)
        
        if result:
            self._log_allocation(process_id, process_size, algorithm, True)
        else:
            self._log_allocation(process_id, process_size, algorithm, False)
        
        return result
    
    def first_fit(self, process_size, process_id):
        """First Fit: Allocate first available block"""
        for block in self.blocks:
            if block.is_free and block.size >= process_size:
                return self._allocate_block(block, process_size, process_id)
        return None
    
    def best_fit(self, process_size, process_id):
        """Best Fit: Allocate smallest sufficient block"""
        best_block = None
        min_size = float('inf')
        
        for block in self.blocks:
            if block.is_free and block.size >= process_size:
                if block.size < min_size:
                    min_size = block.size
                    best_block = block
        
        if best_block:
            return self._allocate_block(best_block, process_size, process_id)
        return None
    
    def worst_fit(self, process_size, process_id):
        """Worst Fit: Allocate largest available block"""
        worst_block = None
        max_size = 0
        
        for block in self.blocks:
            if block.is_free and block.size >= process_size:
                if block.size > max_size:
                    max_size = block.size
                    worst_block = block
        
        if worst_block:
            return self._allocate_block(worst_block, process_size, process_id)
        return None
    
    def next_fit(self, process_size, process_id):
        """Next Fit: Like First Fit but continues from last allocation"""
        if not hasattr(self, 'last_allocated_index'):
            self.last_allocated_index = 0
        
        # Search from last position to end
        for i in range(self.last_allocated_index, len(self.blocks)):
            block = self.blocks[i]
            if block.is_free and block.size >= process_size:
                self.last_allocated_index = i
                return self._allocate_block(block, process_size, process_id)
        
        # Wrap around and search from beginning
        for i in range(0, self.last_allocated_index):
            block = self.blocks[i]
            if block.is_free and block.size >= process_size:
                self.last_allocated_index = i
                return self._allocate_block(block, process_size, process_id)
        
        return None
    
    def buddy_allocate(self, process_size, process_id):
        """Buddy System Allocation"""
        # Calculate required order (power of 2)
        required_order = math.ceil(math.log2(max(process_size, 1)))
        required_size = 2 ** required_order
        
        # Find suitable block
        block = self._find_buddy_block(required_order)
        
        if block:
            block.is_free = False
            block.process_id = process_id
            block.allocated_at = datetime.now().isoformat()
            
            # Calculate internal fragmentation
            block.internal_fragmentation = block.size - process_size
            
            return block
        return None
    
    def _find_buddy_block(self, required_order):
        """Find or create buddy block of required order"""
        # Look for exact match
        for block in self.blocks:
            if block.is_free and block.buddy_order == required_order:
                return block
        
        # Look for larger block to split
        for block in self.blocks:
            if block.is_free and block.buddy_order and block.buddy_order > required_order:
                return self._split_buddy_block(block, required_order)
        
        return None
    
    def _split_buddy_block(self, block, target_order):
        """Split buddy block until reaching target order"""
        while block.buddy_order > target_order:
            index = self.blocks.index(block)
            half_size = block.size // 2
            new_order = block.buddy_order - 1
            
            # Create two buddy blocks
            left_buddy = MemoryBlock(block.start, half_size, True, block_type='buddy')
            left_buddy.buddy_order = new_order
            
            right_buddy = MemoryBlock(block.start + half_size, half_size, True, block_type='buddy')
            right_buddy.buddy_order = new_order
            
            # Replace original block with two buddies
            self.blocks[index] = left_buddy
            self.blocks.insert(index + 1, right_buddy)
            
            block = left_buddy
        
        return block
    
    def _allocate_block(self, block, size, process_id):
        """Internal method to allocate memory from a block"""
        index = self.blocks.index(block)
        
        # Calculate internal fragmentation
        internal_frag = block.size - size if block.size > size else 0
        
        # Create allocated block
        allocated = MemoryBlock(block.start, size, False, process_id)
        allocated.internal_fragmentation = internal_frag
        allocated.allocated_at = datetime.now().isoformat()
        
        # If block is larger than needed, split it
        if block.size > size:
            remaining = MemoryBlock(block.start + size, block.size - size, True)
            self.blocks[index] = allocated
            self.blocks.insert(index + 1, remaining)
        else:
            self.blocks[index] = allocated
        
        self.allocation_count += 1
        return allocated
    
    def deallocate(self, process_id):
        """Deallocate memory with buddy coalescing support"""
        for block in self.blocks:
            if block.process_id == process_id:
                block.is_free = True
                block.process_id = None
                block.allocated_at = None
                
                if self.enable_buddy and block.block_type == 'buddy':
                    self._coalesce_buddies()
                
                return True
        return False
    
    def _coalesce_buddies(self):
        """Coalesce buddy blocks"""
        merged = True
        while merged:
            merged = False
            i = 0
            while i < len(self.blocks) - 1:
                current = self.blocks[i]
                next_block = self.blocks[i + 1]
                
                # Check if blocks are buddies and both free
                if (current.is_free and next_block.is_free and 
                    current.block_type == 'buddy' and next_block.block_type == 'buddy' and
                    current.buddy_order == next_block.buddy_order and
                    current.size == next_block.size):
                    
                    # Merge buddies
                    merged_block = MemoryBlock(current.start, current.size * 2, True, block_type='buddy')
                    merged_block.buddy_order = current.buddy_order + 1
                    
                    self.blocks[i] = merged_block
                    self.blocks.pop(i + 1)
                    merged = True
                else:
                    i += 1
    
    def _log_allocation(self, process_id, size, algorithm, success):
        """Log allocation events"""
        self.allocation_history.append({
            'timestamp': datetime.now().isoformat(),
            'process_id': process_id,
            'size': size,
            'algorithm': algorithm,
            'success': success
        })
        
        # Keep only last 100 entries
        if len(self.allocation_history) > 100:
            self.allocation_history.pop(0)
    
    def get_memory_state(self):
        """Get current memory state with enhanced metrics"""
        allocated_blocks = [b for b in self.blocks if not b.is_free]
        free_blocks = [b for b in self.blocks if b.is_free]
        
        total_allocated = sum(b.size for b in allocated_blocks)
        total_free = sum(b.size for b in free_blocks)
        total_internal_frag = sum(b.internal_fragmentation for b in allocated_blocks)
        
        return {
            'blocks': [block.to_dict() for block in self.blocks],
            'total_memory': self.total_memory,
            'allocated': total_allocated,
            'free': total_free,
            'external_fragmentation': self._calculate_external_fragmentation(),
            'internal_fragmentation': total_internal_frag,
            'internal_fragmentation_percent': (total_internal_frag / self.total_memory * 100) if self.total_memory > 0 else 0,
            'total_fragmentation': total_internal_frag + (self._calculate_external_fragmentation() * self.total_memory / 100),
            'num_free_blocks': len(free_blocks),
            'num_allocated_blocks': len(allocated_blocks),
            'largest_free_block': max((b.size for b in free_blocks), default=0),
            'allocation_count': self.allocation_count,
            'buddy_system_enabled': self.enable_buddy
        }
    
    def _calculate_external_fragmentation(self):
        """Calculate external fragmentation percentage"""
        free_blocks = [b for b in self.blocks if b.is_free]
        if not free_blocks:
            return 0
        
        total_free = sum(b.size for b in free_blocks)
        largest_free = max((b.size for b in free_blocks), default=0)
        
        if total_free == 0:
            return 0
        
        return ((total_free - largest_free) / self.total_memory) * 100
    
    def get_allocation_history(self):
        """Get allocation history for diagnostics"""
        return self.allocation_history
    
    def reset(self):
        """Reset memory to initial state"""
        self.allocation_count = 0
        self.allocation_history = []
        
        if self.enable_buddy:
            self._init_buddy_system()
        else:
            self.blocks = [MemoryBlock(0, self.total_memory, True)]